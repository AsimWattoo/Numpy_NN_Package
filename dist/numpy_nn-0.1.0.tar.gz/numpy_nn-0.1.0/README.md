# Numpy_NN_Package
This is the package containing Neural Network implemented from scratch
